import { IUser } from "./IUser";

export type IUserFindOneData = Partial<IUser>
