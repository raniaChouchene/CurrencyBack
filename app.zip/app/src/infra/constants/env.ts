export const { DATABASE_URL } = process.env;

export const { SECRET_KEY } = process.env;
